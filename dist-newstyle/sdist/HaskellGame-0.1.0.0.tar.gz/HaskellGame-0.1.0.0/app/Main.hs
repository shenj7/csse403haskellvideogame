module Main(main) where

import Graphics.Gloss
import Graphics.Gloss.Data.ViewPort
import Graphics.Gloss.Interface.Pure.Game

-- | Model

data VideoGame = Game {
    player :: (Float, Float)
}


-- | View

window :: Display
window = InWindow "Nice Window" (200, 200) (10, 10)

background :: Color
background = white

drawing :: Picture
drawing = circle 80

-- | Controller

main :: IO ()
main = display window background drawing
